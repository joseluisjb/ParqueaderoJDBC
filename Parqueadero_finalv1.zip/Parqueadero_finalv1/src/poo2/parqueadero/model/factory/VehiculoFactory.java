package poo2.parqueadero.model.factory;

import poo2.parqueadero.model.dao.CarroDAO;
import poo2.parqueadero.model.dao.MotoDAO;
import poo2.parqueadero.model.dao.VehiculoDTO;

public interface VehiculoFactory {
    public CarroDAO crearCarroDAO();
    public MotoDAO crearMotoDAO();
}
