package poo2.parqueadero.model.factory;

import poo2.parqueadero.model.dao.CarroDAO;
import poo2.parqueadero.model.dao.MotoDAO;
import poo2.parqueadero.model.dao.VehiculoDTO;

public class VehiculoFactoryJDBC implements VehiculoFactory{

	@Override
	public CarroDAO crearCarroDAO() {
		return new CarroDAO();
	}

	@Override
	public MotoDAO crearMotoDAO() {
		return new MotoDAO();
	}
}
