package poo2.parqueadero.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MotoDAO {
	
	private Connection conn;
	
	public MotoDAO() {
		try {
			conn = DriverManager.getConnection("jdbc:h2:~/personal", "sa", "1704");
			
		}catch(SQLException e) {
			System.err.println("La conexion no se pudo establecer. " + e.getMessage());
		}
	}
	
	public MotoDAO(Connection conn) {
		this.conn = conn;	
	}
	
	public ArrayList<MotoDTO>listar(){
		ArrayList<MotoDTO> motos = new ArrayList<>();
		Statement statementOb = null;
		try {
			statementOb = conn.createStatement();
			ResultSet rs = statementOb.executeQuery("SELECT * FROM MOTOS");
			while(rs.next()) {
				MotoDTO dto = new MotoDTO();
				dto.setCilindraje(rs.getInt("CILINDRAJE"));
				dto.setMarca(rs.getString("MARCA"));
				dto.setModelo(rs.getString("MODELO"));
				dto.setPlaca(rs.getString("PLACA"));
				dto.setTipo(rs.getString("TIPO"));
				motos.add(dto);
			}
		}catch(Exception e) {
			System.err.println("Se presentó un error ejecutando la consulta. "+e.getMessage());
		}finally {
			// Close the connection            
            try {
            	statementOb.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return motos;
	}
	
	public boolean agregarMoto(String cilindraje, String marca, String modelo, String placa, String tipo) {
		boolean exito = false;
		try {
			Statement statementOb = conn.createStatement();
			String sqlString = "INSERT INTO MOTOS (CILINDRAJE, MARCA, MODELO, PLACA, TIPO) VALUES "
	                + "(" + cilindraje + ", '" + marca + "' , '" +  modelo + "' , '" + placa + "', '" + tipo + "' )";
			statementOb.executeUpdate(sqlString);
			
			exito = true;
			
		}catch(Exception e) {
			System.err.println("Ocurrió un error insertando el registro. "+e.getMessage());
		}finally {
			// Close the connection            
            try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
            
		}
		
		return exito;
	}
	
	public boolean retirarMoto(String placa, int minutos) {
		boolean exito = false;
		try {
			MotoDTO dto = this.buscar(placa);
			if(dto == null) {
				throw new RuntimeException("No se encontró la Moto");
			}
			//System.out.println(conn.isClosed());
			Statement statementOb = conn.createStatement();
			String sqlString = "INSERT INTO MOTOS_HISTORICO (CILINDRAJE, MARCA, MODELO, PLACA, TIPO, MINUTOS) VALUES "
	                + "(" + dto.getCilindraje() + ", '" + dto.getMarca() + "' , '" +  dto.getModelo() + "' , '" + dto.getPlaca() + "', '" + dto.getTipo() + "', " + minutos + ")";
			statementOb.executeUpdate(sqlString);
			statementOb.executeUpdate("DELETE FROM MOTOS WHERE PLACA="+placa);
			System.out.println("Número registros afectados = "+statementOb.getUpdateCount());
			exito = true;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			// Close the connection            
            try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return exito;
	}
	
	public MotoDTO buscar(String placa) {
		MotoDTO dto = null;
		try {
			Statement statementOb = conn.createStatement();
			ResultSet rs = statementOb.executeQuery("SELECT * FROM MOTOS WHERE PLACA = "+ placa);
			if(rs.next()) {
				dto = new MotoDTO();
				dto.setCilindraje(rs.getInt("CILINDRAJE"));
				dto.setMarca(rs.getString("MARCA"));
				dto.setModelo(rs.getString("MODELO"));
				dto.setPlaca(rs.getString("PLACA"));
				dto.setTipo(rs.getString("TIPO"));
			}
		}catch(Exception e) {
			System.err.println("Se presentó un error ejecutando la consulta. "+e.getMessage());
		}/*finally {
			// Close the connection            
            try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}*/
		
		return dto;
	}
	
	public ArrayList<MotoDTO>listarHistorico(){
		ArrayList<MotoDTO> motos = new ArrayList<>();
		Statement statementOb = null;
		try {
			statementOb = conn.createStatement();
			ResultSet rs = statementOb.executeQuery("SELECT * FROM MOTOS_HISTORICO");
			while(rs.next()) {
				MotoDTO dto = new MotoDTO();
				dto.setCilindraje(rs.getInt("CILINDRAJE"));
				dto.setMarca(rs.getString("MARCA"));
				dto.setModelo(rs.getString("MODELO"));
				dto.setPlaca(rs.getString("PLACA"));
				dto.setTipo(rs.getString("TIPO"));
				motos.add(dto);
			}
		}catch(Exception e) {
			System.err.println("Se presentó un error ejecutando la consulta. "+e.getMessage());
		}finally {
			// Close the connection            
            try {
            	statementOb.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return motos;
	} 
	
	public double totalMotos(double tarifaMinuto) {
		double totalMinutos = 0;
		Statement statementOb = null;
		try {
			statementOb = conn.createStatement();
			ResultSet rs = statementOb.executeQuery("SELECT * FROM MOTOS_HISTORICO");
			while(rs.next()) {
				totalMinutos += rs.getInt("MINUTOS");
			}
		}catch(Exception e) {
			System.err.println("Se presentó un error ejecutando la consulta. "+e.getMessage());
		}finally {
			// Close the connection            
            try {
            	statementOb.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return totalMinutos * tarifaMinuto;
	}
	
	
}
