package poo2.parqueadero.model;

import java.util.ArrayList;

import poo2.parqueadero.model.dao.CarroDAO;
import poo2.parqueadero.model.dao.CarroDTO;
import poo2.parqueadero.model.dao.MotoDAO;
import poo2.parqueadero.model.dao.MotoDTO;
import poo2.parqueadero.model.dao.VehiculoDTO;
import poo2.parqueadero.model.factory.VehiculoFactory;
import poo2.parqueadero.model.factory.VehiculoFactoryJDBC;

public class ParqueaderoFachada {
    private static ParqueaderoFachada instance;
    private static double tarifaMoto = 1000;
    public static int TARIFA_CARROS = 10; //costo x minuto de parquear un carro
	private VehiculoFactory ab;

    private ParqueaderoFachada(){}

	public void configurarApp(){
		this.ab = new VehiculoFactoryJDBC();
	}

    public static ParqueaderoFachada getInstance(){
        if(instance == null) {
            instance = new ParqueaderoFachada();
            instance.configurarApp();
        }
        return instance;
    }
    
    public void setTarifaMoto(double precio) {
    	this.tarifaMoto = precio;
    }
    
    public double getTarifaMoto() {
    	return this.tarifaMoto;
    }
    
    public ArrayList<MotoDTO> listarMotos(){
    	MotoDAO dao = ab.crearMotoDAO();
    	ArrayList<MotoDTO> motos = dao.listar();
    	return motos;
    }
    
    public ArrayList<MotoDTO> listarMotosHistorico(){
    	MotoDAO dao = ab.crearMotoDAO();
    	ArrayList<MotoDTO> motos = dao.listarHistorico();
    	return motos;
    }
    
    public boolean retirarMoto(String id, int minutos) {
    	boolean exito = false;
    	MotoDAO dao = ab.crearMotoDAO();
    	exito = dao.retirarMoto(id, minutos);
    	return exito;
    }
    
    public boolean agregarMoto(String cilindraje, String marca, String modelo, String placa, String tipo) {
    	boolean exito = false;
    	MotoDAO dao = ab.crearMotoDAO();
    	exito = dao.agregarMoto(cilindraje, marca, modelo, placa, tipo);
    	return exito;
    }
    
    public MotoDTO obtenerMoto(String placa) {
    	MotoDAO dao = ab.crearMotoDAO();
    	MotoDTO dto = dao.buscar(placa);
    	return dto;
    }
    
    public ArrayList<MotoDTO> listarMoto(){
    	MotoDAO dao = ab.crearMotoDAO();
    	return dao.listar();
    }
    
    public double getTotalMotos() {
    	MotoDAO dao = ab.crearMotoDAO();
    	return dao.totalMotos(tarifaMoto);
    }

    public void registrarCarro(String placa, String marca, String modelo, int cilindraje, int noPuertas) {
    	if(placa.isBlank() || marca.isBlank() || modelo.isBlank())
    		throw new RuntimeException("Los campos deben estar llenos");
    	
    	CarroDAO dao = ab.crearCarroDAO();
    	try {
    		dao.registrarCarro(placa, marca, modelo, cilindraje, noPuertas);
    	} catch(Exception e) {
    		throw new RuntimeException(e.getMessage());
    	}
    	
    }
    
    public void retirarCarro(String placa, int minutos) {
    	if(placa.isBlank())
    		throw new RuntimeException("Placa inválida");
    	
    	CarroDAO dao = ab.crearCarroDAO();
    	try {
    		dao.retirarCarro(placa, minutos);
    	} catch(Exception e) {
    		throw new RuntimeException(e.getMessage());
    	}
    }
    
    public int getMontoCarros() {
    	CarroDAO dao = ab.crearCarroDAO();
    	return dao.getMinutosCarros() * TARIFA_CARROS;
    }
    
    public ArrayList<VehiculoDTO> listar(){
    	CarroDAO dao = ab.crearCarroDAO();
    	return dao.listarCarros();
    }
    
    public ArrayList<CarroDTO> listarHistoricoCarros(){
    	CarroDAO dao = ab.crearCarroDAO();
    	return dao.listarHistoricoCarros();
    }
}
