package poo2.parqueadero.controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import poo2.parqueadero.model.ParqueaderoFachada;
import poo2.parqueadero.model.dao.MotoDTO;

public class IngresarMotoController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<Integer> cboCilindraje;

    @FXML
    private ComboBox<String> cboTipo;

    @FXML
    private Button cmdRegistrarMoto;

    @FXML
    private Button cmdRetirarMoto;
    
    @FXML
    private Button cmdListarMotos;

    @FXML
    private ListView<String> lstVehiculos;

    @FXML
    private TextField txtMarca;

    @FXML
    private TextField txtMinutos;

    @FXML
    private TextField txtModelo;

    @FXML
    private TextField txtPlaca;
    
    private ObservableList<Integer> cilindraje = FXCollections.observableArrayList();
    private ObservableList<String> tipo = FXCollections.observableArrayList();
    private ObservableList<String> listaMotos;
    
    private ParqueaderoFachada fac;
    
    public IngresarMotoController() {
    	fac = ParqueaderoFachada.getInstance();
    	this.listaMotos = FXCollections.observableArrayList();
    	
    }
    
    @FXML
    void registrarMoto(ActionEvent event) {
    	int cilindraje = this.cboCilindraje.getValue();
    	String tipo = this.cboTipo.getValue();
    	String placa = this.txtPlaca.getText();
    	String marca = this.txtMarca.getText();
    	String modelo = this.txtModelo.getText();
    	if(tipo.isBlank() || placa.isBlank() || marca.isBlank() || modelo.isBlank()) {
    		Alert al = new Alert(AlertType.ERROR);
			al.setContentText("Por favor diligencie todos los campos");
			al.show();
    	}else {
    		boolean exito = this.fac.agregarMoto(String.valueOf(cilindraje), marca, modelo, placa, tipo);
    		if(exito) {
    			this.txtMarca.clear();
    			this.txtModelo.clear();
    			this.txtPlaca.clear();
    			this.listarMotos(event);
    		}
    	}
    }
    
    @FXML
    void listarMotos(ActionEvent event) {
    	this.listaMotos.clear();
    	ArrayList<MotoDTO> motos = fac.listarMotos();
    	for(MotoDTO dto : motos) {
    		listaMotos.add(dto.getPlaca() + " - " + dto.getModelo());
    	}
    }

    @FXML
    void retirarMoto(ActionEvent event) {
    	String motoSeleccionada = this.obtenerMotoSeleccionada(this.lstVehiculos);
    	if(motoSeleccionada != null && !motoSeleccionada.isBlank() && !this.txtMinutos.getText().isBlank()) {
    		String id1 = this.obtenerPlacaMotoListView(motoSeleccionada);
    		int minutos = 0;
    		try {
    			minutos = Integer.parseInt(this.txtMinutos.getText());
    		}catch(Exception e) {
    			throw new RuntimeException("Minutos: " + this.txtMinutos.getText() + " invalidos");
    		}
    		boolean exito = fac.retirarMoto(id1, minutos);
    		if(exito) {
    			this.listarMotos(event);
    		}else {
    			Alert al = new Alert(AlertType.ERROR);
    			al.setContentText("Seleccione una Moto.");
    			al.show();
    		}
    	}
    }

    @FXML
    void initialize() {
        assert cboCilindraje != null : "fx:id=\"cboCilindraje\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert cboTipo != null : "fx:id=\"cboTipo\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert cmdRegistrarMoto != null : "fx:id=\"cmdRegistrarMoto\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert cmdRetirarMoto != null : "fx:id=\"cmdRetirarMoto\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert cmdListarMotos != null : "fx:id=\"cmdListarMotos\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert lstVehiculos != null : "fx:id=\"lstVehiculos\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert txtMarca != null : "fx:id=\"txtMarca\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert txtMinutos != null : "fx:id=\"txtMinutos\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert txtModelo != null : "fx:id=\"txtModelo\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        assert txtPlaca != null : "fx:id=\"txtPlaca\" was not injected: check your FXML file 'IngresarMotoView.fxml'.";
        this.initCilindraje();
        this.initTipo();
        this.lstVehiculos.setItems(this.listaMotos);
        listarMotos(null);
    }
    
    private void initTipo(){
        tipo.add("Urbana");
        tipo.add("Carretera");
        tipo.add("Callejera");
        cboTipo.setItems(tipo);
    }

    private void initCilindraje(){
        cilindraje.add(200);
        cilindraje.add(300);
        cilindraje.add(400);
        cboCilindraje.setItems(cilindraje);
    }

    private String obtenerMotoSeleccionada(ListView<String> listView) {
    	String motoSeleccionada = this.lstVehiculos.getSelectionModel().getSelectedItem();
    	return motoSeleccionada;
    }
    
    private String obtenerPlacaMotoListView(String motoSeleccionada) {
    	int posGuion = motoSeleccionada.indexOf("-");
    	String id1 = motoSeleccionada.substring(0, posGuion).trim();
		return id1;
    }
}
