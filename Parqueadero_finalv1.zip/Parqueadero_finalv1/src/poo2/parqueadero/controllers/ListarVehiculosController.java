/**
 * Sample Skeleton for 'ListarVehiculosView.fxml' Controller Class
 */

 package poo2.parqueadero.controllers;

 import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
 import javafx.scene.control.Label;
 import javafx.scene.control.ListView;
import poo2.parqueadero.model.ParqueaderoFachada;
import poo2.parqueadero.model.dao.CarroDTO;
import poo2.parqueadero.model.dao.MotoDAO;
import poo2.parqueadero.model.dao.MotoDTO;
 
 public class ListarVehiculosController {
	 
	 private ParqueaderoFachada fac;
	 private ObservableList<String> listaMotos;
	 
	 public ListarVehiculosController() {
		 this.fac = ParqueaderoFachada.getInstance();
		 this.listaMotos = FXCollections.observableArrayList();
		 //this.listarMotos();
	 }
	 
     @FXML // ResourceBundle that was given to the FXMLLoader
     private ResourceBundle resources;
 
     @FXML // URL location of the FXML file that was given to the FXMLLoader
     private URL location;
 
     @FXML // fx:id="lblTotalCarros"
     private Label lblTotalCarros; // Value injected by FXMLLoader
 
     @FXML // fx:id="lblTotalMotos"
     private Label lblTotalMotos; // Value injected by FXMLLoader
 
     @FXML // fx:id="lblTotalVehiculos"
     private Label lblTotalVehiculos; // Value injected by FXMLLoader
 
     @FXML // fx:id="lstCarros"
     private ListView<CarroDTO> lstCarros; // Value injected by FXMLLoader
 
     @FXML // fx:id="lstMotos"
     private ListView<String> lstMotos; // Value injected by FXMLLoader
     
     private ObservableList<CarroDTO> carros = FXCollections.observableArrayList();
          
     private void actualizarMontoCarros() {
    	 lblTotalCarros.setText("$" + fac.getMontoCarros());
     }
     
     void listarMotos() {
     	this.listaMotos.clear();
     	ArrayList<MotoDTO> motos = fac.listarMotosHistorico();
     	for(MotoDTO dto : motos) {
     		listaMotos.add(dto.getPlaca() + " - " + dto.getModelo());
     	}
     	this.lstMotos.setItems(this.listaMotos);
     }
 
     @FXML // This method is called by the FXMLLoader when initialization is complete
     void initialize() {
         assert lblTotalCarros != null : "fx:id=\"lblTotalCarros\" was not injected: check your FXML file 'ListarVehiculosView.fxml'.";
         assert lblTotalMotos != null : "fx:id=\"lblTotalMotos\" was not injected: check your FXML file 'ListarVehiculosView.fxml'.";
         assert lblTotalVehiculos != null : "fx:id=\"lblTotalVehiculos\" was not injected: check your FXML file 'ListarVehiculosView.fxml'.";
         assert lstCarros != null : "fx:id=\"lstCarros\" was not injected: check your FXML file 'ListarVehiculosView.fxml'.";
         assert lstMotos != null : "fx:id=\"lstMotos\" was not injected: check your FXML file 'ListarVehiculosView.fxml'.";
		 this.lstMotos.setItems(this.listaMotos);
		 this.listarMotos();
		 this.lblTotalMotos.setText("");
		 this.lblTotalMotos.setText(String.valueOf(fac.getTotalMotos()));
		 initListCarros();
         carros.setAll(fac.listarHistoricoCarros());
         actualizarMontoCarros();
         actualizarMontoTotal();
     }
     
     private void initListCarros() {
      	lstCarros.setItems(carros);
      }
     
     private void actualizarMontoTotal() {
    	 lblTotalVehiculos.setText(Double.toString(fac.getMontoCarros()+fac.getTotalMotos()));
     }
 
 }
 